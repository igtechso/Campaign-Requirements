<?php
include("conn.php");
session_start();
if (empty($_SESSION['email']) || empty($_SESSION['id'])) {
  echo "Error: Someting is wrong";
}
else{
    $camp_id=$_POST['camp_id'];
	$item_id=$_POST['item_id'];
	$vote_type=$_POST['vote_type'];
	$current_rank=$_POST['current_rank'];
	$user_email = $_SESSION['email'];
	$user_id = $_SESSION['id'];
	
	if($camp_id != '' && $item_id != '' && $vote_type != ''){
	    $votecheck_sql = "SELECT * FROM camp_users_vote where user_id=".$user_id." and item_id=".$item_id;
    	$votecheck_result = mysqli_query($conn, $votecheck_sql);
    	if (mysqli_num_rows($votecheck_result) > 0) {
    	    echo json_encode(array("statusCode"=>200,"message"=>"Vote already submitted"));
    	}
    	else{
    	    //echo "done";
    	    if($vote_type == "voteup"){
    	        $user_vote = 1;
    	    }else if($vote_type == "votedown") {
    	        $user_vote = 0;
    	    }
    	    
    	    $addvote_sql = "INSERT INTO camp_users_vote (user_id, user_email, camp_id, item_id, user_vote, open_rank) VALUES ('$user_id', '$user_email', '$camp_id', '$item_id', '$user_vote', '$current_rank')";
            
            if (mysqli_query($conn, $addvote_sql)) {
              echo json_encode(array("statusCode"=>200,"message"=>"Vote submitted"));
            } else {
              echo json_encode(array("statusCode"=>503,"message"=>"Error: " . $sql . "<br>" . mysqli_error($conn)));
            }
    	    
    	}
	    
	}
	
	
}