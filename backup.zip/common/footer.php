      </div>
    </div>

    <div class="modal fade" id="resModal">
      <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
          <!-- Modal body -->
            <div class="modal-body">
                <div class="res-msg"></div>
            </div>
        </div>
      </div>
    </div>
    
    <div class="modal fade" id="stkinfoModal">
      <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
          <!-- Modal body -->
            <div class="modal-body">
                <div class="stkinfo-details"></div>
            </div>
        </div>
      </div>
    </div>
    <div class="camp-loader"><img src="images/loading.gif" /></div>
  <script src="js/campjs.js"></script>
</body>
</html>